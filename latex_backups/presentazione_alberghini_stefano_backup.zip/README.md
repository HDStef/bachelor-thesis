# SimplePlus Beamer Theme

This is a **simple** and **clear** beamer theme for academic and scientific presentations. It is originally based on the Madrid beamer theme and [SimplePlus Beamer Theme](https://github.com/PM25/SimplePlus-BeamerTheme). 

## AIC visual identity
SimplePlus theme was adapted to use the [visual identity of AIC](https://smart-helenium-3a1.notion.site/Visual-identity-e194f93a8645492b8d00d52d759f61cc) in terms of logotypes, colors and font selections.